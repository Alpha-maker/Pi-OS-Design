/*
 * sched.c
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */


#include <circle/sched.h>
#include "../../pi-OS/include/circle/timer.h"
#include <circle/taskswitch.h>
#include <circle/logger.h>
//#include <circle/timer.h>
#define TASKKERNELID 0
#define TASKKERNELNUM 0
#define TASKSCHEDID 1
#define TASKSCHEDNUM 1
#define NULL 0

const char FromScheduler[] = "Scheduler";
static int counter; ///counter need to be static, or arm-gcc would give a wrong experiment result


//CAAUSION: don't change variable declaration, no matter location or feature
static int taskIDcounter = 0;
static Tscheduler scheduler;
static sysCall systemCall;

void InitializeScheduler()
{
	int i;
	taskIDcounter = 100;
	scheduler.pCurrentTask = 0;
	scheduler.pLastTask = 0;
	scheduler.lastTaskSwitchReason = KERNELSWITCHING;
	for (i = 0 ; i< MAXTASK; i++){
		scheduler.taskQueue[i] = 0;
	}
	systemCall.yield = &yield;
	systemCall.sleep = (void (*)(void*, unsigned int))(&sleep);
	systemCall.exit = &exit;
}

//systemCall,scheduler must be accessed by getSysCallPointer.
//Although they can be accessed directly from other source files, they are not the same
sysCall * getSysCallPointer()
{
	return &systemCall;
}

Tscheduler * getScheduler()
{
	return &scheduler;
}

void startScheduler(Task * pKernelTask, int ALGORITHM)
{
	int taskNum = 0;
	int SchedFlag = 1;
	scheduler.pCurrentTask = pKernelTask;

	pKernelTask->pSysCall->print("---------------------- enter scheduler ----------------------");

	while (--counter) // number of tasks, excluded kernel task.
	{
		scheduler.lastTaskSwitchReason = KERNELSWITCHING;
		scheduler.pCurrentTask = scheduler.taskQueue[1];

		switch(ALGORITHM)
		{
		case SCHED_FIFO:
			taskNum = scheduleFIFO();
			break;
		case SCHED_PRIORITY:
			taskNum = schedulePriority();
			break;
		default:
			taskNum = scheduleFIFO();
			break;
		}


		if (0 == taskNum){
			pKernelTask->pSysCall->print("There's no ready task in queue now, scheduler quiet");
			counter = 0;
			scheduler.SchedulerState = NOREADYTASK;
			break;
		}

		if (MAXTASK == taskNum){
			pKernelTask->pSysCall->print("There's no task with appropriate priority in queue now, scheduler quiet");
			counter = 0;
			scheduler.SchedulerState = NOREADYTASK;
			break;
		}
		//Going to switch to user task

		//pKernelTask->pSysCall->printV("in taskNum=%d", taskNum);
		kernelYieldByNum(taskNum);
		//pKernelTask->pSysCall->printV("out taskNum=%d", taskNum);
		pKernelTask->pSysCall->print("return control to scheduler");

	}
	scheduler.SchedulerState = NOREADYTASK;
	pKernelTask->pSysCall->print("---------------------- exit scheduler ----------------------");

}


/*scheduling task: TASK ID=1; TASK NUM = 1;
 * This Run function is for scheduling task. But it will not run.
 * Its task num is 1, and its entry will be override as returning point in kernelYield.
 * We need this "task", currently only for the purpose of storing returning address.
 * It's not a runnable task now, the first will begin after scheduling task
 */
void schedulerRun(Task * taskSched)
{
	int ALGORITHM = SCHED_FIFO;
	int taskNum = GetNextTask();
	static int counter = 2;
	taskSched->pSysCall->print("Now we are in the schedulerRun");
	scheduler.pCurrentTask = taskSched;
	CLogger::Get ()->Write (FromScheduler, LogPanic, "schedulerRusdgsdfg    dfg ");

	//switchToTask(taskNum);//This will switch to Application in the task queue
	kernelYield();
	taskSched->pSysCall->print("someone  schedulerRun");

}


int schedulePriority()
{
	int preTaskNum = 0;
	int taskNum = 0;
	int i = 0;
	int highest_priority = 100;
	int heighest_priority_task_num = 100;
	Task * heighestPriorityTask;
	for(i=2; i< MAXTASK;i++){

		if ( 0 != scheduler.taskQueue[i]  && TaskStateReady == scheduler.taskQueue[i]->State){

			if( scheduler.taskQueue[i]->priority < highest_priority){
				heighest_priority_task_num = i;
				heighestPriorityTask = scheduler.taskQueue[i];
				highest_priority = scheduler.taskQueue[i]->priority;
			}

		}
	}
	taskNum = heighest_priority_task_num;
	return taskNum;
}

int scheduleFIFO()
{
	int preTaskNum = 0;
	int taskNum = 0;
	preTaskNum = getTaskNumByTaskPointer(scheduler.pLastTask);

	switch(scheduler.lastTaskSwitchReason)
	{
	case APPENDS:
		RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateTerminated;
		break;
	case APPEXIT:
		RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateTerminated;
		break;
	case APPSLEEPING:
		//RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateSleeping;
		break;
	default:
		break;
	}

	// TODO: project 2

	taskNum = GetNextTaskByPosition(preTaskNum);
	return taskNum;
}

int  getTaskNumByTaskPointer(Task *pTask)
{
	int i;
	if(0 == pTask)
	{
		return MAXTASK;
	}
	for (i = 0 ; i< MAXTASK; i++){
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.taskQueue[i]){
			return i;
		}
	}
	return MAXTASK;
}



int genTaskID()
{
	return taskIDcounter ++;
}


void AddTask (Task *pTask)
{
	int i;
	for (i = 0 ; i< MAXTASK; i++){
		if(0 == scheduler.taskQueue[i]){
			scheduler.taskQueue[i] = pTask;
			counter++;
			break;
		}
	}

}
void BlockTask (Task **ppTask);

void WakeTask (Task **ppTask);		// can be called from interrupt context

void RemoveTaskFromQueue (Task *pTask)
{
	int i;

	for (i = 0 ; i< MAXTASK; i++){
		if(pTask == scheduler.taskQueue[i]){
			scheduler.taskQueue[i] = 0;
			break;
		}
	}
}
/*
 * called by scheduler only. Select the next task after current task in the queue
 * kernel task doesn't participate the selecting procedure
 */
unsigned GetNextTask (void)
{
	int i;
	boolean posFlag;
	posFlag = FALSE;
	for (i = 0 ; i< MAXTASK; i++){
		//select next task after current task
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i]){
			return i;
		}
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.taskQueue[i]){
			posFlag = TRUE;
			continue;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 2 ; i< MAXTASK; i++){
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return 0;
}


unsigned GetNumOfNextReadyTask (void)
{
	int i;
	boolean posFlag;
	posFlag = FALSE;
	// if currentTask is scheduler, start scaning from first user task
	if(scheduler.pCurrentTask == scheduler.taskQueue[1]){
		posFlag = TRUE;
	}

	for (i = KERNELTASKNUM + 2; i< MAXTASK; i++){
		//select next task after current task
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i] && TaskStateReady == scheduler.taskQueue[i]->State){
			return i;
		}
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.taskQueue[i]){
			posFlag = TRUE;
			continue;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 2 ; i< MAXTASK; i++){
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i] && TaskStateReady == scheduler.taskQueue[i]->State){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return 0;
}

unsigned GetNextTaskByPosition (int CurTaskNum)
{
	int i;
	for (i = CurTaskNum+1 ; i< MAXTASK; i++){
		//select next task after current task
		if ( 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 1 ; i< MAXTASK; i++){
		if ( 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return 0;
}


unsigned GetNumOfNextReadyTaskByPosition (int CurTaskNum)
{
	int i;
	for (i = CurTaskNum+1 ; i< MAXTASK; i++){
		//select next task after current task
		if ( 0 != scheduler.taskQueue[i] && TaskStateReady == scheduler.taskQueue[i]->State){
			return i;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 2 ; i< MAXTASK; i++){
		if ( 0 != scheduler.taskQueue[i]  && TaskStateReady == scheduler.taskQueue[i]->State){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return MAXTASK;
}


/*
 * Application calls yield, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * yield means Application reaches the end of code normally
 */
void yield (void)
{
	Task *pNext ;

	int nextNum = TASKSCHEDNUM;
	pNext = scheduler.taskQueue[nextNum];

	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	RemoveTaskFromQueue (scheduler.pCurrentTask);

	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPENDS;
	scheduler.pCurrentTask = pNext;

	TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?
	//pNext->pSysCall->print("will this appear?");
}



void kernelYield (void)
{
	//CLogger::Get ()->Write (FromScheduler, LogPanic, "Yield: print some info ");
	Task *pNext; //          = scheduler.taskQueue[KERNELTASKNUM];

	int nextNum = GetNextTask ();
	//nextNum = 1;
	pNext = scheduler.taskQueue[nextNum];

	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPENDS;
	scheduler.pCurrentTask = pNext;
	TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?
}


void kernelYieldByNum (int nextNum)
{
	Task *pNext;
	pNext = scheduler.taskQueue[nextNum];

	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPENDS;
	scheduler.pCurrentTask = pNext;
	TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?
}

/*
 *
 * Called only by scheduler ( kernel )
 * @ numTask: the position number of the target task, in the task queue
 */
void switchToTask (int numTask)
{

	Task *pNext = scheduler.taskQueue[1]; ///MODIFIED
	//pNext->pSysCall->print("task switching 000000000");
	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs); //kernel regs
	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = KERNELSWITCHING;
	scheduler.pCurrentTask = pNext;
	pNext->pSysCall->print("task switching now");

	//save current CPU registers to kernel regs; switch to App registers
	kernelYield();

	///MODIFIED
	//TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?
	pNext->pSysCall->print("task switching over, this should not appear");
}


/*
 * Application calls sleep, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * sleep means Application doesn't finish, and it want to run at some time later
 */
void sleepYield (void)
{
	// TODO: project 2



}


/*
 * Application calls exit, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * The task will also be removed from task queue, and print some debugging information
 */
void exit()
{

	Task *pNext = scheduler.taskQueue[KERNELTASKNUM];
	//RemoveTaskFromQueue(scheduler.pCurrentTask);
	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPEXIT;
	scheduler.pCurrentTask = pNext;
	TaskSwitch (pOldRegs, pNewRegs); //which line will be executed next? Why?

}


void sleep (Task *pTask, unsigned nSeconds)
{
	// be sure the clock does not run over taken as signed int
	const unsigned nSleepMax = 1800;	// normally 2147 but to be sure
	pTask->pSysCall->print("sleep is called ");
	pTask->State = TaskStateSleeping;
	scheduler.lastTaskSwitchReason = APPSLEEPING;

	if (nSeconds > nSleepMax)
	{
		msSleep(pTask, nSleepMax);
	}
	else{
		// addKernelTimer is in unit of 10ms
		msSleep(pTask, 100* nSeconds);
	}
}

void msSleep (Task *pTask, unsigned nMilliSeconds)
{
	pTask->pSysCall->print("msSleep is called");

	// TODO: project 2
	// IMPORTANT: addKernelTimer is in unit of 10ms


}



void sleepTimerHandler (unsigned hTimer, void *pParam, void *pContext)
{

	Task *pTask = (Task *) pParam;
	pTask->pSysCall->print("timer went off");
	pTask->pSysCall->print("sleepTimerHandler is called ");

	// TODO: project 2


}

void schedulerSleepTimerHandler(unsigned hTimer, void *pParam, void *pContext)
{
	Tscheduler *pTask = (Tscheduler *) pParam;
	pTask->pCurrentTask->pSysCall->print("timer went off");
	pTask->pCurrentTask->pSysCall->print("schedulerSleepTimerHandler is called ");

	// TODO: project 2

}
