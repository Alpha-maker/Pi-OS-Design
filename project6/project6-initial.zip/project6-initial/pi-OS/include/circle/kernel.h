//
// kernel.h
//
// Circle - A C++ bare metal environment for Raspberry Pi
// Copyright (C) 2016  R. Stange <rsta2@o2online.de>
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
#ifndef _kernel_h
#define _kernel_h

#include "../../../pi-OS/include/circle/actled.h"
#include "../../../pi-OS/include/circle/devicenameservice.h"
#include "../../../pi-OS/include/circle/exceptionhandler.h"
#include "../../../pi-OS/include/circle/input/touchscreen.h"
#include "../../../pi-OS/include/circle/interrupt.h"
#include "../../../pi-OS/include/circle/koptions.h"
#include "../../../pi-OS/include/circle/logger.h"
#include "../../../pi-OS/include/circle/memory.h"
#include "../../../pi-OS/include/circle/screen.h"
#include "../../../pi-OS/include/circle/serial.h"
#include "../../../pi-OS/include/circle/timer.h"
#include "../../../pi-OS/include/circle/types.h"
#include "../../../pi-OS/include/circle/SDCard/emmc.h"
#include <circle/fs/fat/fatfs.h>
#include "../../../pi-OS/include/circle/task.h"
#include "../../../pi-OS/include/circle/sched.h"
#include "../../../pi-OS/include/circle/list.h"
#include "../../../pi-OS/include/circle/ipc.h"



enum TShutdownMode
{
	ShutdownNone,
	ShutdownHalt,
	ShutdownReboot
};

struct TKernelTimer
{
#ifndef NDEBUG
	unsigned	     m_nMagic;
#define KERNEL_TIMER_MAGIC	0x4B544D43
#endif
	TKernelTimerHandler *m_pHandler;
	unsigned	     m_nElapsesAt;
	void 		    *m_pParam;
	void 		    *m_pContext;
};

#define FORKFLAG 0
#define VFORKFLAG 1



class CKernel
{
public:
	CKernel (void);
	~CKernel (void);

	boolean Initialize (void);
	static TKernelTimer * kernel_timer;
	TShutdownMode Run (void);
	TShutdownMode FileRun (void);
	int vfsInitialize (void);
	int AutoMount (void);
	void *  vfsOpen(char * name, unsigned permit);
	void *  vfsCreate (char * name);
	int vfsRead (void * fileHandler, char *Buffer, unsigned size);
	int vfsWrite (void *  fileHandler, char *Buffer, unsigned size);
	int vfsSeek (void *  fileHandler, int offset);
	int vfsClose (void *  fileHandler);

	//int addTaskToRunQueue(task_struct * pTask);
	int addTaskToTaskQueue(task_struct * pTask);
	int schedNewTask(task_struct * pTask);
	task_struct * createTaskStruct(char * name, int prio);
	int initTask(task_struct * pTask, void (* enter)(task_struct * task), void (* run)());



	int fork();
	int forkInitChildTask(task_struct * pTask);
	int threadExit();
	int wait();
/*
 * flag = 0 mean frok; flag = 1 mean vfork
 * fork & vfork: fn==0 then execute same program as parent
 * fork: separate stack; vfork: same stack as current parent sp; restore sp upon finishing
 * fork: lightweight process, don't affact parent
 * vfork: a new thread but need to finish before resuming parent
 */
	int clone(int flag, void (* fn)(), void* child_stack, int * ptid);

	//All ipc function: return 0 if succeed; return 1 if fail
	int ipcInitialize (void);
	int ipcCreate(const char * topic);
	int ipcSubscribe(const char * topic);
	int ipcSend(void * msg_send);
	int ipcReceive(void * msg_receive);


	void write_log(const char * message, ...);
	void write_logV(const char * message, va_list Args);
	void set_timer(unsigned nDelay);
	static void TimerHandler (unsigned hTimer, void *pParam, void *pContext);
	void addKernelTimer (unsigned nDelay, TKernelTimerHandler *pHandler, void *pParam);

private:
	static void TouchScreenEventHandler (TTouchScreenEvent Event,
					     unsigned nID, unsigned nPosX, unsigned nPosY);
	
private:
	// do not change this order
	CMemorySystem		m_Memory;
	CActLED			m_ActLED;
	CKernelOptions		m_Options;
	CDeviceNameService	m_DeviceNameService;
	CScreenDevice		m_Screen;
	CExceptionHandler	m_ExceptionHandler;
	CInterruptSystem	m_Interrupt;
	CTimer			m_Timer;
	CLogger			m_Logger;

	CEMMCDevice		m_EMMC;
	CFATFileSystem		m_FileSystem;
	static CKernel *s_pThis;
};

#endif
