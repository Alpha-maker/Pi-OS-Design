/*
 * task_def.h
 *
 *  Created on: Feb 9, 2017
 *      Author: wangfakai
 */

#ifndef PI_OS_INCLUDE_CIRCLE_TASK_DEF_H_
#define PI_OS_INCLUDE_CIRCLE_TASK_DEF_H_

typedef struct TTaskRegisters
{
	u32	r0;
	u32	r1;
	u32	r2;
	u32	r3;
	u32	r4;
	u32	r5;
	u32	r6;
	u32	r7;
	u32	r8;
	u32	r9;
	u32	r10;
	u32	r11;
	u32	r12;
	u32	sp;
	u32	lr;
}TaskRegisters;

#endif /* PI_OS_INCLUDE_CIRCLE_TASK_DEF_H_ */
