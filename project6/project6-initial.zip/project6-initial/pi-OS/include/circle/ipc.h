/*
 * ipc.h
 *
 *  Created on: May 3, 2017
 *      Author: wangfakai
 */

#ifndef PI_OS_INCLUDE_CIRCLE_IPC_H_
#define PI_OS_INCLUDE_CIRCLE_IPC_H_

#include "../../../pi-OS/include/circle/list.h"

typedef struct Tmessage_struct{
	char topic[32];
	char sender_name[32];
	int points;  // Receiver can get points from this messsage
	int msg_id;
	char msg[64];
}message_struct;

#define MAX_SUBSCRIBER_NUM 10
typedef struct Ttopic_struct{
	char topic[32];
	int subscriber_number;
	struct Ttask_struct* owner;
	struct Ttask_struct* subscriber_list[MAX_SUBSCRIBER_NUM];
}topic_struct;


#endif /* PI_OS_INCLUDE_CIRCLE_IPC_H_ */
