/*
 * gettask.h
 *
 *  Created on: Mar 5, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_PI_LIBC_GETTASK_H_
#define PROJECT3_PI_OS_INCLUDE_PI_LIBC_GETTASK_H_

void * getCurrentTaskPtr();

#endif /* PROJECT3_PI_OS_INCLUDE_PI_LIBC_GETTASK_H_ */
