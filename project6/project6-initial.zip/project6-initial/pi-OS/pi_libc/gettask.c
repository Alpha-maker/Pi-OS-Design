/*
 * gettask.c
 *
 *  Created on: Mar 5, 2017
 *      Author: wangfakai
 */


#include <pi_libc/gettask.h>


void * getCurrentTaskPtr(){
	int res=0;
	asm("swi 1004");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;

}
