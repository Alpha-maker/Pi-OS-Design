/*
 * pi-lib.c
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */


#include <circle/stdarg.h>
#include <pi_libc/libc_api.h>
#include "../../pi-OS/include/pi_libc/print.h"
#include "../../pi-OS/include/circle/task.h"
#include "../../pi-OS/include/pi_libc/sleepswitch.h"
#include "../../pi-OS/include/pi_libc/forkswitch.h"


static TTaskRegisters TRegs;

////*********   pi-OS-specific system call 1000 ~1100  *********//////

//system call number: 1000;
int pi_lib_test(int a, int b, int c){
	int res=0;
	asm("swi 1000");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 1001;
int printf(const char * pMessage,...){

	va_list var;
	va_start (var, pMessage);
	call_printf(pMessage, var);
	va_end (var);
}

//system call number: 1002;
int sleep(int nSeconds){
	//asm("push {r0}");
	task_struct * pTask = getCurrentTaskPtr();
	TTaskRegisters *pOldRegs = &(pTask->Regs);
	//asm("pop {r1}");
	SleepSwitch(pOldRegs,nSeconds);

}


int sleep_temp(int pOldRegs,int nSeconds);

//system call number: 1003;
void * getKernelRegPtr(){
	int res=0;
	asm("swi 1003");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 1004;
void * getCurrentTaskPtr(){
	int res=0;
	asm("swi 1004");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

////////******   Linux system call  0 ~ 337 *******//////

//system call number: 0;
int restart(int ERRNUM){
	asm("swi 0");
}

//system call number: 1;
int exit(int ERRNUM){
	asm("swi 1");
}


//system call number: 3;
int read(void * pFile, char * buffer, int size){
	int res=0;
	asm("swi 3");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 4;
int write(void * pFile, char * buffer, int size){
	int res=0;
	asm("swi 4");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 5;
void * open(char * name, int permit){
	int res=0;
	asm("swi 5");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 6;
int close(void * pFile){
	int res=0;
	asm("swi 6");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}


//system call number: 7;
int seek(void * pFile, int offset){
	int res=0;
	asm("swi 7");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 10;
int fork(int arg){
	int res=0;

	task_struct * pTask = getCurrentTaskPtr();
	TTaskRegisters *pOldRegs = &(pTask->Regs);
	ForkSwitch(pOldRegs,arg);
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}


//system call number: 11;
int wait(int arg){
	int res=0;
	task_struct * pTask = getCurrentTaskPtr();
	TTaskRegisters *pOldRegs = &(pTask->Regs);
	if(pTask->active_child_count == 0){
		return 0;
	}
	WaitSwitch(pOldRegs, arg);
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}


//All ipc function: return 0 if succeed; return 1 if fail
//system call number: 20;
int ipc_create(const char * topic){
	int res=0;
	asm("swi 20");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 21;
int ipc_subscribe(const char * topic){
	int res=0;
	asm("swi 21");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 22;
int ipc_send( message_struct * msg_send){
	int res=0;
	asm("swi 22");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 23;
int ipc_receive(message_struct * msg_receive ){
	int res=0;
	asm("swi 23");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}




