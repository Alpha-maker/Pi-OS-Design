
#include <assert.h>
#include <circle/stdarg.h>
#include "../../pi-OS/include/circle/softwareinterrupt.h"
#include "../../pi-OS/include/circle/synchronize.h"


//INCLUDE kernel header files, so second level handler can call kernel functions
#include "../../pi-OS/include/circle/sched.h"

static CKernel * pKernel;

void setKernelPointer(CKernel * pointerKernel){
	pKernel= pointerKernel;
}

int SWIHandler (unsigned r0, unsigned r1, unsigned r2, unsigned r3)
{
	PeripheralExit ();	// exit from interrupted peripheral
	if( 1001 != r3){  // don't need to print printf REGs,
		//pKernel->write_log("SWIHandler::second level SVC handler, r0=%d,r1=%d,r2=%d,r3=%d", r0, r1, r2, r3);
	}

	switch(r3){
	case 1:
		yieldPrepare();
		//pKernel->write_log("--       SWIHandler::yieldPrepare is called");
		return 0xFFFF0000;
		break;

	case 3:
		return pKernel->vfsRead((void *)r0, (char *)r1, r2);
		break;
	case 4:
		//TODO
		return 0;
		break;
	case 5:
		//TODO
		return 0;
		break;
	case 6:
		//TODO
		return 0;
		break;
	case 7:
		//TODO
		return 0;
		break;



	case 1000: //printf(char *)
		return r0 + r1 * r2;
		break;
	case 1001:
		pKernel->write_log((const char *)r0);
		break;
	case 1002:
		//pKernel->write_log("--       SWIHandler::sleepYieldPrepare is called");
		sleepYieldPrepare (r0, (void *)r1);
		//yieldPrepare();
		return 0xFFFF0000;
		break;
	case 1003:
		//pKernel->write_log("--       SWIHandler::getKernelRegPtr is called");
		//pKernel->write_log("return addr=%x", getKernelRegPtr ());
		return getKernelRegPtr ();

	case 1004:
		//pKernel->write_log("--       SWIHandler::getCurrentTaskPointer is called");
		//pKernel->write_log("return addr=%x", getCurrentTaskPointer ());
		return getCurrentTaskPointer ();
		break;

	default:
		pKernel->write_log("--       SWIHandler:: Receive an undefined system call !");
		break;

	}
	PeripheralEntry ();	// continuing with interrupted peripheral
	return 0;
}

