//
// kernel.cpp
//
// Circle - A C++ bare metal environment for Raspberry Pi
// Copyright (C) 2016  R. Stange <rsta2@o2online.de>
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
#include "../../pi-OS/include/circle/kernel.h"
#include "../../pi-OS/include/circle/util.h"
#include "../../pi-OS/include/circle/alloc.h"

#include <assert.h>
#include "../../pi-OS/include/circle/string.h"

static const char FromKernel[] = "kernel";
#define SDCard_PARTITION	"emmc1-1"
#define FILENAME	"circle.txt"

CKernel *CKernel::s_pThis = 0;

#define INODE_DATA_BUFFER_LEN 512  //certain bufffer size for each inode data block
#define INODEMAGIC 0x0447
#define INODELISTLEN 512




typedef struct inode{
	unsigned magic;
	unsigned file_size;
	char file_name[FS_TITLE_LEN];
	unsigned hFile;
	int file_offset;
	int use_count;
	int dirty_flag;
	unsigned permit;
	char data[INODE_DATA_BUFFER_LEN];
	inode * next;
};

static inode * inode_list[INODELISTLEN];
unsigned inode_count=0;


void removeInodeFromList(inode * ptr);
inode * findInodePtrByName(char * name);
int checkNameEqual(char * name1, char * name2);
int checkNameValid(char * name);

CKernel::CKernel (void)
:	m_Screen (1280, 1024),
	m_Timer (&m_Interrupt),
	m_Logger (m_Options.GetLogLevel (), &m_Timer),
	m_EMMC (&m_Interrupt, &m_Timer, &m_ActLED)

{
	s_pThis = this;

}

CKernel::~CKernel (void)
{
	s_pThis = 0;
}

boolean CKernel::Initialize (void)
{
	boolean bOK = TRUE;

	if (bOK)
	{
		bOK = m_Screen.Initialize ();
	}

	if (bOK)
	{
		CDevice *pTarget =  &m_Screen;

		bOK = m_Logger.Initialize (pTarget);
	}

	if (bOK)
	{
		bOK = m_Interrupt.Initialize ();
	}

	if (bOK)
	{
		bOK = m_Timer.Initialize ();
	}

	m_Logger.Write (FromKernel, LogNotice, "Compile time: " __DATE__ " " __TIME__);

	if (bOK)
	{
		bOK = m_EMMC.Initialize ();
	}
	m_Logger.Write (FromKernel, LogNotice, "Compile time: " __DATE__ " " __TIME__);
	return bOK;
}

#define FILENAME2 "circl2.txt"
TShutdownMode CKernel::Run (void)
{


	// Create file and write to it
	unsigned hFile = m_FileSystem.FileOpen (FILENAME2);
	if (hFile == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot open ssss file: %s", FILENAME2);
	}

	for (unsigned nLine = 1; nLine <= 2; nLine++)
	{
		CString Msg;
		Msg.Format ("enee File2! (Line %u)\n", nLine);
		int result = m_FileSystem.FileWrite (hFile, (const char *) Msg, Msg.GetLength ());
		if (result != Msg.GetLength ())
		{
			m_Logger.Write (FromKernel, LogError, "Write error");
			write_log("ERROR return is %d", result);
			break;
		}
	}

	if (!m_FileSystem.FileClose (hFile))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot close file");
	}

	// Reopen file, read it and display its contents
	hFile = m_FileSystem.FileOpen (FILENAME2);
	if (hFile == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot open file: %s", FILENAME2);
	}

	char Buffer[100];
	unsigned nResult;
	while ((nResult = m_FileSystem.FileRead (hFile, Buffer, sizeof Buffer)) > 0)
	{
		if (nResult == FS_ERROR)
		{
			m_Logger.Write (FromKernel, LogError, "Read error 000099999");
			break;
		}

		m_Screen.Write (Buffer, nResult);
	}

	if (!m_FileSystem.FileClose (hFile))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot close file");
	}

	return ShutdownHalt;
}



void CKernel::addKernelTimer (unsigned nDelay,
		   TKernelTimerHandler *pHandler,
		   void *pParam)
{
	m_Timer.StartKernelTimer (nDelay, pHandler, pParam);
}




void CKernel::write_log(const char * pMessage, ...)
{
	//(const char *pSource, TLogSeverity Severity, const char *pMessage, ...)
	//m_Logger.Write (FromKernel, LogNotice, (const char *) pMessage);
	va_list var;
	va_start (var, pMessage);

	m_Logger.WriteV (FromKernel, LogNotice, pMessage, var);

	va_end (var);
}


void CKernel::write_logV(const char * pMessage, va_list Args)
{
	//(const char *pSource, TLogSeverity Severity, const char *pMessage, ...)
	//m_Logger.Write (FromKernel, LogNotice, (const char *) pMessage);
	//va_list var;
	//va_start (var, pMessage);

	m_Logger.WriteV (FromKernel, LogNotice, pMessage, Args);

	//va_end (var);
}


void CKernel::set_timer(unsigned nDelay )
{
	//CKernel::kernel_timer = (TKernelTimer * )
	m_Timer.StartKernelTimer (nDelay, TimerHandler, this);
	//this->write_log("timer eclipse = %d", CKernel::kernel_timer->m_nElapsesAt);


}

void CKernel::TimerHandler (unsigned hTimer, void *pParam, void *pContext)
{
	CKernel *pThis = (CKernel *) pParam;
	assert (pThis != 0);
	pThis->write_log("timer eclipse = asdf");
	//pThis->write_log("this is from kernel timer handler");
}

typedef enum {
	O_RDONLY,
	O_RDWR
}FILE_PERMIT;



void removeInodeFromList(inode * ptr){
	int i;
	for(i=0;i<INODELISTLEN;i++){
		if(inode_list[i] == ptr){
			inode_list[i] = 0;
		}
	}
}

int CKernel::vfsInitialize (void)
{
	int i;
	m_Logger.Write (FromKernel, LogNotice, "VFS initializing ...");
	memset(inode_list, 0, INODELISTLEN);
	AutoMount();
	return 0;
}


int CKernel::AutoMount (void)
{
	m_Logger.Write (FromKernel, LogNotice, "Compile time: " __DATE__ " " __TIME__);

	// Mount file system
	CDevice *pPartition = m_DeviceNameService.GetDevice (SDCard_PARTITION, TRUE);
	if (pPartition == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Partition not found: %s", SDCard_PARTITION);
	}

	if (!m_FileSystem.Mount (pPartition))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot mount partition: %s", SDCard_PARTITION);
	}


	return 0;
}


int checkNameValid(char * name){
	int i;
	for (i=0;i< FAT_DIR_NAME_LENGTH+1;i++){

		if(*(name+i) ==0){
			break;
		}
		if(*(name+i) < 40 || *(name+i) > 127){
			return 0;
		}
	}
	if(*(name+i) != 0){
		return 0;
	}
	return 1;
}


inode * findInodePtrByName(char * name){
	int i;
	for(i=0;i<INODELISTLEN;i++){
		if(inode_list[i] == 0){
			continue;
		}
		if(inode_list[i]->magic != INODEMAGIC){
			continue;
		}
		if(checkNameEqual (inode_list[i]->file_name, name) == 1){
			return inode_list[i];
		}
	}
	return 0;
}

/*
 * file name maximum length: 11 (FAT_DIR_NAME_LENGTH)
 */
int checkNameEqual(char * name1, char * name2){

	int i;
	for (i=0;i< FAT_DIR_NAME_LENGTH;i++){
		if(*(name1+i) != *(name2 +i)){
			return 0;
		}
		if(*(name1+i) ==0){
				break;
		}
	}
	if(i==0 || *(name1+i) != 0){
		return 0;
	}
	return 1;
}



/*
 * name length < 11; permit 0 or 1
 * return 0 upon failure
 */
void *  CKernel::vfsOpen (char * name, unsigned permit)
{
	//TODO
	return 0;
}
/*
 * return 0 upon success; other value if fail
 */
int CKernel::vfsSeek (void *  fileHandler, int offset)
{
	//TODO
	return 0;
}

int CKernel::vfsRead (void *  fileHandler, char *Buffer, unsigned size)
{
	//TODO
	return 0;
}

int CKernel::vfsWrite (void *  fileHandler, char *Buffer, unsigned size)
{
	//TODO
	return 0;
}

/*
 * return 0 upon success; other value if fail
 */
int CKernel::vfsClose (void * fileHandler)
{
//TODO
	return 0;
}









//------------below just for test ------//////

TShutdownMode CKernel::FileRun (void)
{
	m_Logger.Write (FromKernel, LogNotice, "Compile time: " __DATE__ " " __TIME__);

	// Mount file system
	CDevice *pPartition = m_DeviceNameService.GetDevice (SDCard_PARTITION, TRUE);
	if (pPartition == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Partition not found: %s", SDCard_PARTITION);
	}

	if (!m_FileSystem.Mount (pPartition))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot mount partition: %s", SDCard_PARTITION);
	}

	// Show contents of root directory
	TDirentry Direntry;
	TFindCurrentEntry CurrentEntry;
	unsigned nEntry = m_FileSystem.RootFindFirst (&Direntry, &CurrentEntry);
	for (unsigned i = 0; nEntry != 0; i++)
	{
		if (!(Direntry.nAttributes & FS_ATTRIB_SYSTEM))
		{
			CString FileName;
			FileName.Format ("%-14s", Direntry.chTitle);

			m_Screen.Write ((const char *) FileName, FileName.GetLength ());

			if (i % 5 == 4)
			{
				m_Screen.Write ("\n", 1);
			}
		}

		nEntry = m_FileSystem.RootFindNext (&Direntry, &CurrentEntry);
	}
	m_Screen.Write ("\n", 1);

	// Create file and write to it
	unsigned hFile = m_FileSystem.FileCreate (FILENAME);
	if (hFile == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot create file: %s", FILENAME);
	}

	for (unsigned nLine = 1; nLine <= 5; nLine++)
	{
		CString Msg;
		Msg.Format ("Hello File! (Line %u)\n", nLine);

		if (m_FileSystem.FileWrite (hFile, (const char *) Msg, Msg.GetLength ()) != Msg.GetLength ())
		{
			m_Logger.Write (FromKernel, LogError, "Write error");
			break;
		}
	}

	if (!m_FileSystem.FileClose (hFile))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot close file");
	}

	// Reopen file, read it and display its contents
	hFile = m_FileSystem.FileOpen (FILENAME);
	if (hFile == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot open file: %s", FILENAME);
	}

	char Buffer[100];
	unsigned nResult;
	while ((nResult = m_FileSystem.FileRead (hFile, Buffer, sizeof Buffer)) > 0)
	{
		if (nResult == FS_ERROR)
		{
			m_Logger.Write (FromKernel, LogError, "Read error a234");
			break;
		}

		m_Screen.Write (Buffer, nResult);
	}

	if (!m_FileSystem.FileClose (hFile))
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot close file");
	}

	return ShutdownHalt;
}

void *  CKernel::vfsCreate (char * name)
{
	int i;
	inode * inodePtr = findInodePtrByName(name);
	if (inodePtr != 0 && INODEMAGIC == inodePtr->magic){
		inodePtr->use_count ++;
		return inodePtr;
	}

	unsigned hFile = m_FileSystem.FileCreate (name);
	if (hFile == 0)
	{
		m_Logger.Write (FromKernel, LogPanic, "Cannot open file: %s", FILENAME);
	}


	inode  * new_node = (inode *)malloc(sizeof(inode));
	strncpy (new_node->file_name, name, FS_TITLE_LEN);
	new_node->hFile = hFile;
	new_node->magic = INODEMAGIC;
	new_node->use_count = 1;


	inode_list[inode_count ++ ] = new_node;
	return new_node; // return the inode pointer as the file handler
}



