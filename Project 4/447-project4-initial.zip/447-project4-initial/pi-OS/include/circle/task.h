/*
 * task.h
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */

#ifndef PI_OS_INCLUDE_CIRCLE_TASK_H_
#define PI_OS_INCLUDE_CIRCLE_TASK_H_

#include <circle/sysconfig.h>
#include <circle/types.h>
#include <circle/taskswitch.h>
#include <circle/syscall.h>


#ifdef __cplusplus
extern "C" {
#endif

#define STACKSIZE	100

typedef enum
{
	TaskStateReady,
	TaskStateBlocked,
	TaskStateSleeping,
	TaskStateTerminated,
	TaskStateUnknown
}TTaskState;


typedef struct TTask
{
	u32 		ID;
	char 	name[32];
	volatile 	TTaskState State;
	struct TTask * pSelf;
	unsigned priority;
	void (*Run)(void * pTask);
	void (*RunFunc)();
	void (*taks_entry)(void * pTask);
	unsigned	WakeTicks;
	TTaskRegisters	   Regs;

	u8		   *pStack;
	unsigned	    StackSize;
	sysCall * pSysCall;


}Task;



void initializeTask(Task * pTask, unsigned ID, void (* enter)(Task * task), void (* run)(), void * sysCall);
void InitializeRegs (Task * pTask);
void TaskEntry ( Task * pTask);
void task1_run();
void task2_run();
void task3_run();
void task4_run();
void task5_run();
void task6_run();
void task7_run();
void task8_run();
void taskMatrix_run();



#ifdef __cplusplus
}
#endif




#endif /* PI_OS_INCLUDE_CIRCLE_TASK_H_ */
