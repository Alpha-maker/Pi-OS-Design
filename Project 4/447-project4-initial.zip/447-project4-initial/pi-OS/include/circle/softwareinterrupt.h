/*
 * softwareinterrupt.h
 *
 *  Created on: Mar 1, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_CIRCLE_SOFTWAREINTERRUPT_H_
#define PROJECT3_PI_OS_INCLUDE_CIRCLE_SOFTWAREINTERRUPT_H_
#include "../../../pi-OS/include/circle/exceptionstub.h"
#include "../../../pi-OS/include/circle/kernel.h"


void setKernelPointer(CKernel * pointerKernel);


#endif /* PROJECT3_PI_OS_INCLUDE_CIRCLE_SOFTWAREINTERRUPT_H_ */
