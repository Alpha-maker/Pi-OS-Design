/*
 * pi-lib.h
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_CIRCLE_PI_LIB_H_
#define PROJECT3_PI_OS_INCLUDE_CIRCLE_PI_LIB_H_


void pi_lib_test_pre(int a, int b, int c,int d);

void printf_pre(const char * pMessage,...);

#endif /* PROJECT3_PI_OS_INCLUDE_CIRCLE_PI_LIB_H_ */
