/*
 * pi-lib.h
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_PI_LIBC_LIBC_API_H_
#define PROJECT3_PI_OS_INCLUDE_PI_LIBC_LIBC_API_H_

#include "../../../pi-OS/include/pi_libc/types.h"





int exit(int ERRNUM);


int pi_lib_test(int a, int b, int c);
int printf(const char * pMessage,...);
int sleep(int nSeconds);
void * getKernelRegPtr();
void * getCurrentTaskPtr();





#endif /* PROJECT3_PI_OS_INCLUDE_CIRCLE_PI_LIB_H_ */
