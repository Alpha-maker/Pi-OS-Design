/*
 * sched.c
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */


#include <circle/sched.h>
#include "../../pi-OS/include/circle/timer.h"
#include <circle/taskswitch.h>
#include <circle/logger.h>
//#include <circle/timer.h>
#define TASKSCHEDID 1
#define TASKSCHEDNUM 1

const char FromScheduler[] = "Scheduler";


//CAAUSION: don't change variable declaration, no matter location or feature
static int taskIDcounter = 0;
static Tscheduler scheduler;
static sysCall systemCall;

void InitializeScheduler()
{
	int i;
	taskIDcounter = 100;
	scheduler.pCurrentTask = 0;
	scheduler.pLastTask = 0;
	scheduler.lastTaskSwitchReason = KERNELSWITCHING;
	for (i = 0 ; i< MAXTASK; i++){
		scheduler.taskQueue[i] = 0;
	}
	systemCall.yield = &yield;
	systemCall.sleep = (void (*)(void*, unsigned int))(&sleep);
	systemCall.exit = &exit;
}

//systemCall,scheduler must be accessed by getSysCallPointer.
//Although they can be accessed directly from other source files, they are not the same
sysCall * getSysCallPointer()
{
	return &systemCall;
}

Tscheduler getScheduler()
{
	return scheduler;
}

void startScheduler(Task * pKernelTask, int ALGORITHM)
{
	int taskNum = 0;
	int SchedFlag = 1;
	static int counter; ///counter need to be static, or arm-gcc would give a wrong experiment result
	pKernelTask->pSysCall->print("Now we are in the scheduler");
	scheduler.pCurrentTask = pKernelTask;
	counter =5;  // when this value is bigger than the total number of runnable tasks, error occurs.
	//ALGORITHM = SCHED_PRIORITY;
	while( counter --)
	{
		scheduler.pCurrentTask = pKernelTask;

		switch(ALGORITHM)
		{
		case SCHED_FIFO:
			taskNum = scheduleFIFO();
			break;
		case SCHED_PRIORITY:
			taskNum = schedulePriority();
			break;
		default:
			taskNum = scheduleFIFO();
			break;
		}


		if (0 == taskNum){
			pKernelTask->pSysCall->print("There's no task in queue now, scheduler quite");
			counter = 0;
			break;
		}

		if (100 == taskNum){
			pKernelTask->pSysCall->print("There's no task with appropriate priority in queue now, scheduler quite");
			counter = 0;
			break;
		}

		scheduler.lastTaskSwitchReason = KERNELSWITCHING;
		scheduler.pCurrentTask = scheduler.taskQueue[TASKSCHEDNUM];
		kernelYield();
		//TODO  You need to use kernelYieldByNum instead of kernelYield
		//kernelYieldByNum(taskNum);
		pKernelTask->pSysCall->print("someone return the control to scheduler");

	}
	pKernelTask->pSysCall->print("going out of scheduler");

}


/*scheduling task: TASK ID=1; TASK NUM = 1;
 * This Run function is for scheduling task. But it will not run.
 * Its task num is 1, and its entry will be override as returning point in kernelYield.
 * We need this "task", currently only for the purpose of storing returning address.
 * It's not a runnable task now, the first will begin after scheduling task
 */
void schedulerRun(Task * taskSched)
{
	int ALGORITHM = SCHED_FIFO;
	int taskNum = GetNextTask();
	static int counter = 2;
	taskSched->pSysCall->print("Now we are in the schedulerRun");
	scheduler.pCurrentTask = taskSched;
	CLogger::Get ()->Write (FromScheduler, LogPanic, "schedulerRusdgsdfg    dfg ");

	//switchToTask(taskNum);//This will switch to Application in the task queue
	kernelYield();
	taskSched->pSysCall->print("someone  schedulerRun");

}

//implement priority scheduling algorithm here
int schedulePriority()
{
//TODO

}

int scheduleFIFO()
{
	int preTaskNum = 0;
	int taskNum = 0;
	preTaskNum = getTaskNumByTaskPointer(scheduler.pLastTask);
	switch(scheduler.lastTaskSwitchReason)
	{
	case APPENDS:
		RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateTerminated;
		break;
	case APPEXIT:
		RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateTerminated;
		break;
	case APPSLEEPING:
		//RemoveTaskFromQueue(scheduler.pLastTask);
		scheduler.pLastTask->State = TaskStateSleeping;
		break;
	default:
		break;
	}
	taskNum = GetNextTaskByPosition(preTaskNum);
	return taskNum;
}

int  getTaskNumByTaskPointer(Task *pTask)
{
	int i;
	if(0 == pTask)
	{
		return 0;
	}
	for (i = 0 ; i< MAXTASK; i++){
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.taskQueue[i]){
			return i;
		}
	}
	return MAXTASK;
}



int genTaskID()
{
	return taskIDcounter ++;
}


void AddTask (Task *pTask)
{
	int i;
	for (i = 0 ; i< MAXTASK; i++){
		if(0 == scheduler.taskQueue[i]){
			scheduler.taskQueue[i] = pTask;
			break;
		}
	}

}
void BlockTask (Task **ppTask);

void WakeTask (Task **ppTask);		// can be called from interrupt context

void RemoveTaskFromQueue (Task *pTask)
{
	int i;

	for (i = 0 ; i< MAXTASK; i++){
		if(pTask == scheduler.taskQueue[i]){
			scheduler.taskQueue[i] = 0;
			break;
		}
	}
}
/*
 * called by scheduler only. Select the next task after current task in the queue
 * kernel task doesn't participate the selecting procedure
 */
unsigned GetNextTask (void)
{
	int i;
	boolean posFlag;
	posFlag = FALSE;
	for (i = 0 ; i< MAXTASK; i++){
		//select next task after current task
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i]){
			return i;
		}
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.taskQueue[i]){
			posFlag = TRUE;
			continue;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 2 ; i< MAXTASK; i++){
		if ( TRUE == posFlag && 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return 0;
}


unsigned GetNextTaskByPosition (int CurTaskNum)
{
	int i;
	for (i = CurTaskNum+1 ; i< MAXTASK; i++){
		//select next task after current task
		if ( 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 1 ; i< MAXTASK; i++){
		if ( 0 != scheduler.taskQueue[i]){
			return i;
		}
	}
	//if return 0, then no user task in the queue (only the kernel task)
	return 0;
}


/*
 * Application calls yield, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * yield means Application reaches the end of code normally
 */
void yield (void)
{
	Task *pNext ;

	int nextNum = GetNextTask ();
	pNext = scheduler.taskQueue[nextNum];

	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	RemoveTaskFromQueue (scheduler.pCurrentTask);

	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPENDS;
	scheduler.pCurrentTask = pNext;

	TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?

	//pNext->pSysCall->print("will this appear?");
}



void kernelYield (void)
{

	Task *pNext;

	int nextNum = GetNextTask ();
	pNext = scheduler.taskQueue[nextNum];

	TTaskRegisters *pOldRegs = &(scheduler.pCurrentTask->Regs);
	TTaskRegisters *pNewRegs = &(pNext->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask; // scheduler need to know last task to continuing scheduling
	scheduler.lastTaskSwitchReason = APPENDS;
	scheduler.pCurrentTask = pNext;
	TaskSwitch (pOldRegs, pNewRegs);//which line will be executed next? Why?
}



//TODO  You need to implement kernelYieldByNum
void kernelYieldByNum (int nextNum)
{
//TODO  You need to implement kernelYieldByNum
}

/*
 *
 * Called only by scheduler ( kernel )
 * @ numTask: the position number of the target task, in the task queue
 */
void switchToTask (int numTask)
{

}


/*
 * Application calls sleep, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * sleep means Application doesn't finish, and it want to run at some time later
 */
void sleepYield (void)
{

}


/*
 * Application calls exit, record switch reason, then return control to kernel.
 * (scheduler is part of the kernel, and currently kernel stops at scheduler, saved in scheduler.taskQueue[KERNELTASKNUM])
 * The task will also be removed from task queue, and print some debugging information
 */
void exit()
{

}


void sleep (Task *pTask, unsigned nSeconds)
{
	// be sure the clock does not run over taken as signed int
	const unsigned nSleepMax = 1800;	// normally 2147 but to be sure
	pTask->State = TaskStateSleeping;
	scheduler.lastTaskSwitchReason = APPSLEEPING;
	while (nSeconds > nSleepMax)
	{
		usSleep (pTask, nSleepMax * 1000000);

		nSeconds -= nSleepMax;
	}

	usSleep (pTask, nSeconds * 1000000);
}

void msSleep (Task *pTask, unsigned nMilliSeconds)
{
	if (nMilliSeconds > 0)
	{
		usSleep (pTask, nMilliSeconds * 1000);
	}
}


void usSleep (Task *pTask, unsigned nMicroSeconds)
{
	if (nMicroSeconds > 0)
	{
		unsigned nTicks = nMicroSeconds * (CLOCKHZ / 1000000);

		unsigned nStartTicks = CTimer::Get()->GetClockTicks();

		pTask->WakeTicks =  (nStartTicks + nTicks);
		pTask->State =  (TaskStateSleeping);

		sleepYield ();
	}
}



