//
// bcmpropertytags.cpp
//
// Circle - A C++ bare metal environment for Raspberry Pi
// Copyright (C) 2014-2016  R. Stange <rsta2@o2online.de>
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
// 
#include "../../pi-OS/include/circle/bcmpropertytags.h"

#include <assert.h>

#include "../../pi-OS/include/circle/util.h"
#include "../../Pi-OS/include/circle/bcm2835.h"
#include "../../Pi-OS/include/circle/synchronize.h"
#include "../../Pi-OS/include/circle/sysconfig.h"

struct TPropertyBuffer
{
	u32	nBufferSize;			// bytes
	u32	nCode;
	#define CODE_REQUEST		0x00000000
	#define CODE_RESPONSE_SUCCESS	0x80000000
	#define CODE_RESPONSE_FAILURE	0x80000001
	u8	Tags[0];
	// end tag follows
};

CBcmPropertyTags::CBcmPropertyTags (void)
:	m_MailBox (BCM_MAILBOX_PROP_OUT)
{
}

CBcmPropertyTags::~CBcmPropertyTags (void)
{
}

boolean CBcmPropertyTags::GetTag (u32 nTagId, void *pTag, unsigned nTagSize, unsigned nRequestParmSize)
{
	assert (pTag != 0);
	assert (nTagSize >= sizeof (TPropertyTagSimple));

	TPropertyTag *pHeader = (TPropertyTag *) pTag;
	pHeader->nTagId = nTagId;
	pHeader->nValueBufSize = nTagSize - sizeof (TPropertyTag);
	pHeader->nValueLength = nRequestParmSize & ~VALUE_LENGTH_RESPONSE;

	if (!GetTags (pTag, nTagSize))
	{
		return FALSE;
	}

	if (!(pHeader->nValueLength & VALUE_LENGTH_RESPONSE))
	{
		return FALSE;
	}

	pHeader->nValueLength &= ~VALUE_LENGTH_RESPONSE;
	if (pHeader->nValueLength == 0)
	{
		return FALSE;
	}

	return TRUE;
}

boolean CBcmPropertyTags::GetTags (void *pTags, unsigned nTagsSize)
{
	assert (pTags != 0);
	assert (nTagsSize >= sizeof (TPropertyTagSimple));
	unsigned nBufferSize = sizeof (TPropertyBuffer) + nTagsSize + sizeof (u32);
	assert ((nBufferSize & 3) == 0);

#ifndef USE_RPI_STUB_AT
	TPropertyBuffer *pBuffer = (TPropertyBuffer *) MEM_COHERENT_REGION;
#else
	TPropertyBuffer *pBuffer;
	u32 nSize;

	asm volatile
	(
		"push {r0-r1}\n"
		"mov r0, #1\n"
		"bkpt #0x7FFA\n"	// get coherent region from rpi_stub
		"mov %0, r0\n"
		"mov %1, r1\n"
		"pop {r0-r1}\n"

		: "=r" (pBuffer), "=r" (nSize)
	);

	assert (pBuffer != 0);
	assert (nSize >= nBufferSize);
#endif

	pBuffer->nBufferSize = nBufferSize;
	pBuffer->nCode = CODE_REQUEST;
	memcpy (pBuffer->Tags, pTags, nTagsSize);

	u32 *pEndTag = (u32 *) (pBuffer->Tags + nTagsSize);
	*pEndTag = PROPTAG_END;

	DataSyncBarrier ();

	u32 nBufferAddress = GPU_MEM_BASE + (u32) pBuffer;
	if (m_MailBox.WriteRead (nBufferAddress) != nBufferAddress)
	{
		return FALSE;
	}

	DataMemBarrier ();

	if (pBuffer->nCode != CODE_RESPONSE_SUCCESS)
	{
		return FALSE;
	}

	memcpy (pTags, pBuffer->Tags, nTagsSize);

	return TRUE;
}
