
#include <assert.h>
#include <circle/stdarg.h>
#include "../../pi-OS/include/circle/softwareinterrupt.h"
#include "../../pi-OS/include/circle/synchronize.h"


//INCLUDE kernel header files, so second level handler can call kernel functions
#include "../../pi-OS/include/circle/sched.h"

static CKernel * pKernel;

void setKernelPointer(CKernel * pointerKernel){
	pKernel= pointerKernel;
}

int SWIHandler (unsigned r0, unsigned r1, unsigned r2, unsigned r3)
{
	int res=0;
	PeripheralExit ();	// exit from interrupted peripheral
	if( 1001 != r3){  // don't need to print printf REGs,
		//pKernel->write_log("SWIHandler::second level SVC handler, r0=%d,r1=%d,r2=%d,r3=%d", r0, r1, r2, r3);
	}

	switch(r3){
	case 1:
		pKernel->threadExit();
		yieldPrepare();
		return 0xFFFF0000;
		break;

	case 3:
		return pKernel->vfsRead((void *)r0, (char *)r1, r2);
		break;
	case 4:
		return pKernel->vfsWrite((void *)r0, (char *)r1, r2);
		break;
	case 5:
		return (int)pKernel->vfsOpen((char *)r0, r1);
		break;
	case 6:
		return pKernel->vfsClose((void *)r0);
		break;
	case 7:
		return pKernel->vfsSeek((void *)r0, r1);
		break;

		//----------------------------------------
	case 10:
		pKernel->fork();
		return 0xFFFF0000;
		break;

	case 11:
		res = pKernel->wait();
		if(1 == res){
			return 0xFFFF0000;
		}//Need to wait, yield to scheduler
		break;

	case 1000: //printf(char *)
		return r0 + r1 * r2;
		break;

	case 1001:
		pKernel->write_log((const char *)r0);
		break;

	case 1002:
		sleepYieldPrepare (r0, (void *)r1);
		return 0xFFFF0000;
		break;

	case 1003:
		return getKernelRegPtr ();

	case 1004:
		return getCurrentTaskPointer ();
		break;

	case 1005:
		return getCurrentTaskRegPtr ();
		break;

	default:
		pKernel->write_log("--       SWIHandler:: Receive an undefined system call !");
		break;

	}
	PeripheralEntry ();	// continuing with interrupted peripheral
	return 0;
}

