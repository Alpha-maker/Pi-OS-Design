/*
 * sched.c
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */


#include <circle/sched.h>
#include "../../pi-OS/include/circle/timer.h"
#include "../../pi-OS/include/circle/util.h"
#include <circle/taskswitch.h>

//#include "../../pi-OS/include/circle/string.h"

//#include <circle/timer.h>
#define TASKKERNELID 0
#define TASKKERNELNUM 0
#define TASKSCHEDID 1
#define TASKSCHEDNUM 1
#define NULL 0

const char FromScheduler[] = "Scheduler";


//CAAUSION: don't change variable declaration, no matter location or feature
static int taskIDcounter = 0;
static Tscheduler scheduler;
static sysCall systemCall;

//static void (*addTimer)(unsigned nDelay, TKernelTimerHandler *pHandler, void *pParam);

void InitializeScheduler()
{
	int i;
	taskIDcounter = 100;
	scheduler.pCurrentTask = 0;
	scheduler.pLastTask = 0;
	scheduler.lastTaskSwitchReason = KERNELSWITCHING;
	for (i = 0 ; i< TASKQUEUELEN; i++){
			scheduler.runQueue[i] = 0;
		}
	for (i = 0 ; i< TASKQUEUELEN; i++){
			scheduler.waitQueue[i] = 0;
		}
}

//systemCall,scheduler must be accessed by getSysCallPointer.
//Although they can be accessed directly from other source files, they are not the same
sysCall * getSysCallPointer()
{
	return &systemCall;
}

Tscheduler * getScheduler()
{
	return &scheduler;
}

void setSchedulerTask (task_struct *pTask)
{
	scheduler.pSchedulerTask = pTask;

}


void startScheduler()
{
	int taskIndex = TASKQUEUELEN;
	while( 1 )
	{
		scheduler.pCurrentTask = scheduler.pSchedulerTask;
		taskIndex = schedulePriority();
		if (TASKQUEUELEN == taskIndex){
			systemCall.print("SCHEDULER:: no READY task in queue now, scheduler quite");
			scheduler.SchedulerState = NOREADYTASK;
			break;
		}
		systemCall.printV("SCHEDULER:: going to yield to USER task: Index=%d, PID=%d, PPID=%d, state=%d-------", \
				taskIndex, scheduler.runQueue[taskIndex]->pid, scheduler.runQueue[taskIndex]->parent->pid, scheduler.runQueue[taskIndex]->state);
		kernelYieldByNum(taskIndex);
		systemCall.print("SCHEDULER:: someone return control to scheduler         ++++++");
	}
	scheduler.SchedulerState = NOREADYTASK;
	systemCall.print("SCHEDULER:: going out of scheduler");
}


/*scheduling task: TASK ID=1; TASK NUM = 1;
 * This Run function is for scheduling task. But it will not run.
 * Its task num is 1, and its entry will be override as returning point in kernelYield.
 * We need this "task", currently only for the purpose of storing returning address.
 * It's not a runnable task now, the first will begin after scheduling task
 */
void schedulerRun()
{
}

/*
 * scheduler will select task from this queue to run
 */
void AddTaskToRunQueue (task_struct *pTask){
	int i;
	for (i = 0 ; i< TASKQUEUELEN; i++){
		if(0 == scheduler.runQueue[i]){
			scheduler.runQueue[i] = pTask;
			break;
		}
	}
}

void AddTaskToWaitQueue (task_struct *pTask){
	int i;
	for (i = 0 ; i< TASKQUEUELEN; i++){
		if(0 == scheduler.waitQueue[i]){
			scheduler.waitQueue[i] = pTask;
			break;
		}
	}
}


int schedulePriority()
{
	int taskRunQueueIndex = TASKQUEUELEN;
	int i = 0;
	int highest_priority = 100;
	int heighest_priority_task_num = TASKQUEUELEN;
	//Task * heighestPriorityTask;
	//CString output;
	//systemCall.print("check task in runQueue");
	for(i=0; i< TASKQUEUELEN;i++){
		if ( 0 != scheduler.runQueue[i]) {
			systemCall.printV("queueIndex=%d, pid=%d, ppid=%d, state=%d, prio=%d"\
					, i, scheduler.runQueue[i]->pid, scheduler.runQueue[i]->parent->pid, scheduler.runQueue[i]->state, scheduler.runQueue[i]->prio);
			//output.Append(itoa(10));
			if (TaskStateReady == scheduler.runQueue[i]->state|| TASKRUNNING == scheduler.runQueue[i]->state){
				if( scheduler.runQueue[i]->prio < highest_priority){
					heighest_priority_task_num = i;
					highest_priority = scheduler.runQueue[i]->prio;
				}
			}
		}
	}
	taskRunQueueIndex = heighest_priority_task_num;
	return taskRunQueueIndex;
}

int scheduleFIFO()
{
	int taskNum = MAXTASK;
	//At the beginning, there may be not pLastTask
	if (NULL == scheduler.pLastTask){
		return GetNumOfNextReadyTask();
	}
	return GetNumOfNextReadyTask();

}

int genTaskID()
{
	return taskIDcounter ++;
}


void RemoveTaskFromQueue (Task *pTask)
{
	int i;

	for (i = 0 ; i< MAXTASK; i++){
		if(pTask == scheduler.taskQueue[i]){
			scheduler.taskQueue[i] = 0;
			break;
		}
	}
}


void RemoveTaskFromRunQueue (task_struct *pTask){
	int i;

	//systemCall.print("now in RemoveTaskFromRunQueue");
	for (i = 0 ; i< TASKQUEUELEN; i++){
		if(pTask == scheduler.runQueue[i]){
			//systemCall.printV("remove %d from RemoveTaskFromRunQueue", i);
			scheduler.runQueue[i] = 0;
			break;
		}
	}

}


unsigned GetNumOfNextReadyTask (void)
{
	int i;
	boolean posFlag;
	posFlag = FALSE;
	for (i = 0 ; i< MAXTASK; i++){
		//select next task after current task
		if ( TRUE == posFlag && 0 != scheduler.runQueue[i] && TaskStateReady == scheduler.runQueue[i]->state){
			return i;
		}
		//find the current task, then flag
		if(scheduler.pCurrentTask == scheduler.runQueue[i]){
			posFlag = TRUE;
			continue;
		}
	}
	//if no following task is found, then loop around
	for (i = KERNELTASKNUM + 2 ; i< MAXTASK; i++){
		if ( TRUE == posFlag && 0 != scheduler.runQueue[i] && TaskStateReady == scheduler.runQueue[i]->state){
			return i;
		}
	}
	//if return MAXTASK, then no user task in the queue (only the kernel task)
	return MAXTASK;
}



void kernelYieldByNum (int nextNum)
{
	task_struct *pNext = scheduler.runQueue[nextNum];
	TTaskRegisters *pNewRegs = &(pNext->Regs);

	TTaskRegisters *pOldRegs = &(scheduler.pSchedulerTask->Regs);
	scheduler.pLastTask = scheduler.pCurrentTask;
	scheduler.pCurrentTask = pNext;
	//systemCall.print("kernelYieldByNum");
	TaskSwitch (pOldRegs, pNewRegs);
}



//This function is used by SVC second level handler
//yieldPrepare() is called in the first stage of exit
void yieldPrepare(){
	scheduler.pLastTask = scheduler.pCurrentTask;
	scheduler.lastTaskSwitchReason = APPEXIT;
	RemoveTaskFromRunQueue (scheduler.pLastTask);
	scheduler.pCurrentTask = scheduler.pSchedulerTask;
}

//This function is used by SVC second level handler
//sleepYieldPrepare() is called in the first stage of sleep
void sleepYieldPrepare(unsigned seconds, void *pParam){
	scheduler.pCurrentTask->state = TASKINTERRUPTIBLE;
	systemCall.addKernelTimer(100* seconds, sleepTimerHandler, scheduler.pCurrentTask);
	scheduler.pLastTask = scheduler.pCurrentTask;
	scheduler.lastTaskSwitchReason = APPSLEEPING;
	scheduler.pCurrentTask = scheduler.pSchedulerTask;
}


int getCurrentTaskPointer(){
	return (int)scheduler.pCurrentTask;
}


//getKernelRegPtr() = getschedulerTaskRegPtr()
//This function is used by SVC second level handler
//getKernelRegPtr() is called in the second stage of exit & sleep
int getKernelRegPtr(){
	return (u32)(&scheduler.pSchedulerTask->Regs);
}


int getCurrentTaskRegPtr(){
	return (u32)(&scheduler.pCurrentTask->Regs);
}

void sleepTimerHandler (unsigned hTimer, void *pParam, void *pContext)
{
	task_struct *pTask = (task_struct *) pParam;
	systemCall.print("sleepTimerHandler is called ");
	pTask->state = TaskStateReady;
	scheduler.SchedulerState = NEEDTOSCHED;
}


