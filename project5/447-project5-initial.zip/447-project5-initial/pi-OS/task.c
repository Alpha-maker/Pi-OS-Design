/*
 * task.c
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */

/// 1) INCLUDE pi-OS kernel header files
#include <circle/task.h>
#include <circle/types.h>

/// 2) INCLUDE libc header files
#include <pi_libc/libc_api.h>


void initializeTask(Task * pTask, unsigned ID, void (* enter)(Task * task), void (* run)(), void * sysCall)
{
	pTask->ID = ID;
	pTask->pSelf = pTask;
	pTask->pStack = (Task *) malloc(2*STACKSIZE);
	pTask->StackSize = 2*STACKSIZE;
	InitializeRegs(pTask);

	pTask->taks_entry = enter;
	pTask->RunFunc = run;
	pTask->pSysCall = sysCall;
	pTask->State = TaskStateReady;
}


void InitializeRegs (Task * pTask)
{
	//TaskRegisters * pRegs = &(pTask->Regs);
	memset (&(pTask->Regs), 0, sizeof (pTask->Regs));

	pTask->Regs.r0 = (u32) pTask;		// pParam for TaskEntry()

	pTask->Regs.sp = (u32) (pTask->pStack) + pTask->StackSize;

	pTask->Regs.lr = (u32) &TaskEntry;
}

void TaskEntry (Task * pTask)
{
	printf("Task is entering now");

	pTask->RunFunc ();

	pTask->State = TASKZOMIE;
	pTask->pSysCall->printV("Task:ID=%d is going to terminate normally", pTask->ID);
	exit(1);
}


void InitializeRegs2 (task_struct * pTask)
{
	//TaskRegisters * pRegs = &(pTask->Regs);
	memset (&(pTask->Regs), 0, sizeof (pTask->Regs));

	pTask->Regs.r0 = (u32) pTask;		// pParam for TaskEntry()

	pTask->Regs.sp = (u32) (pTask->pStack) + pTask->StackSize;

	pTask->Regs.lr = (u32) &TaskEntry2;
}


// scheduler would take this as task entry
// This func is actually in user space
void TaskEntry2 (task_struct * pTask)
{
	printf("Task is entering now");

	pTask->RunFunc ();

	if(pTask->active_child_count != 0){
		wait();
	}
	pTask->state = TASKZOMIE;
	exit(1); // system call, and then switch to scheduler
}



void task1_run()
{
	printf("TASK1:  Hello From task1 . -----");
	printf("TASK1:  Task1 has been done.----");
}


void task2_run()
{
	printf("Task2 begins to run . ------");
	int gg = 122;
	int tt=10;
	int yy =9;
	int kk=22;
	int hh=55;
	printf("TASK2:  hello from task2 gg=%d, tt=%d, yy=%d,kk=%d, hh=%d", gg, tt, yy,kk,hh);
	printf("TASK2:  -----------aa");
	sleep(2);
	printf("TASK2:  wake up, continue to work -------bb");
	int result=pi_lib_test(1,2,3);
	printf("TASK2:  result of pi_lib_test(1,2,3) = %d", result);
	sleep(5);
	printf("TASK2:  wake up, continue to work -------cc");
	exit(1);
	printf("TASK2:  this message should not appear");
}

void task3_run()
{
	printf("TASK3:  Now we are in task3 .*****");
	sleep(15);
	printf("TASK3:  wake up, continue to work---- ");
	exit(1);
	printf("TASK3:  this message should not appear");
}

#define BLOCKLEN 512
char file01[] = "test01.txt";
void task4_run()
{
	char buffer[BLOCKLEN];
	int temp;
	memset(buffer, 0, BLOCKLEN);
	char string01[300] = "task4 controls";
	printf("TASK4:  Now we are in task4 .*****");

	exit(1);
	printf("TASK4:  this message should not appear");
}

char file02[] = "test02.txt";
char file03[] = "test03.txt";
void task5_run()
{
	//sleep(10);
	printf("TASK5:  Now we are in task5 .*****");

	exit(1);
	printf("TASK5:  this message should not appear");
}


void task6_run()
{
	printf("TASK6:  Now we are in task6  ************");
	int res = fork(2);
	printf("TASK6: back AAA res = %d ", res);

	if(res == 0) { // child process
		sleep(10);
		res = fork(2);
		printf("TASK6: back BBB res = %d", res);
	}

	if(res != 0) { // parent process
		sleep(5);
		res = fork(2);
		printf("TASK6: back CCC res = %d", res);
	}

	printf("TASK6: back DDD res = %d ", res);
	wait(2);
	printf("TASK6: exit res = %d ", res);
	exit(1);
}


void taskMatrix_run()
{
	printf("Hello from Matrix Task");
   int firstMatrix[3][4] = {
	   {6, 7, 8, 9},
	   {10, 11, 12, 13},
	   {14, 15, 16, 17}
   };
   int secondMatrix[4][3] = {
	   {61, 57, 8},
	   {10, 9, 13},
	   {14, 15, 17},
	   {101, 0, 1}
   };
   int thirdMatrix[3][3];
	int i, j, k;

	// Initializing elements of matrix mult to 0.
	for(i = 0; i < 3; ++i)
	{
		for(j = 0; j < 3; ++j)
		{
			thirdMatrix[i][j] = 0;
		}
	}

	// Multiplying matrix firstMatrix and secondMatrix and storing in array.
	for(i = 0; i < 3; ++i)
	{
		for(j = 0; j < 3; ++j)
		{
			for(k=0; k<4; ++k)
			{
				thirdMatrix[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
			}
		}
	}
	int uu=678;

	printf("Now print the third matrix");
   for (i=0; i<3; i++){
	   printf("\t%d\t%d\t%d\t%d", thirdMatrix[i][0],thirdMatrix[i][1],thirdMatrix[i][2],uu);
   }
}
