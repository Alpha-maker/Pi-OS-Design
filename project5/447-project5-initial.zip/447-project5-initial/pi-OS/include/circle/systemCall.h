/*
 * systemCall.h
 *
 *  Created on: Feb 23, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_CIRCLE_SYSTEMCALL_H_
#define PROJECT3_PI_OS_INCLUDE_CIRCLE_SYSTEMCALL_H_

void print(const char* message);
void printInt(int num);
void printInt2(int num);
void printInt3(int num);

#endif /* PROJECT3_PI_OS_INCLUDE_CIRCLE_SYSTEMCALL_H_ */
