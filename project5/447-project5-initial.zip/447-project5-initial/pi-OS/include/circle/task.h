/*
 * task.h
 *
 *  Created on: Feb 8, 2017
 *      Author: wangfakai
 */

#ifndef PI_OS_INCLUDE_CIRCLE_TASK_H_
#define PI_OS_INCLUDE_CIRCLE_TASK_H_

#include <circle/sysconfig.h>
#include <circle/types.h>
#include <circle/taskswitch.h>
#include <circle/syscall.h>
#include "../../../pi-OS/include/circle/list.h"

#ifdef __cplusplus
extern "C" {
#endif

#define STACKSIZE	256

typedef enum
{
	TaskStateReady,
	TASKRUNNING,
	TASKINTERRUPTIBLE,
	TASKSTOPPED,
	TASKZOMIE,
	TASKDEAD,
	TaskStateUnknown
}TTaskState;


typedef struct TTask
{
	u32 		ID;
	char 	name[32];
	volatile 	TTaskState State;
	struct TTask * pSelf;
	unsigned priority;
	void (*Run)(void * pTask);
	void (*RunFunc)();
	void (*taks_entry)(void * pTask);
	unsigned	WakeTicks;
	TTaskRegisters	   Regs;

	u8		   *pStack;
	unsigned	    StackSize;
	sysCall * pSysCall;


}Task;


typedef struct Ttask_struct{
	int state;
	int prio;
	int policy;
	struct Ttask_struct* parent;
	struct list_head tasks;
	int pid;
	void (*RunFunc)();
	void (*taks_entry)(struct Ttask_struct * pTask);
	unsigned	WakeTicks;
	TTaskRegisters	   Regs;
	u8		   *pStack;
	unsigned	    StackSize;
	int active_child_count;
	int isWaiting;
}task_struct;





void initializeTask(Task * pTask, unsigned ID, void (* enter)(Task * task), void (* run)(), void * sysCall);
void InitializeRegs (Task * pTask);
void InitializeRegs2 (task_struct * pTask);
void TaskEntry ( Task * pTask);
void TaskEntry2 ( task_struct * pTask);
void task1_run();
void task2_run();
void task3_run();
void task4_run();
void task5_run();
void task6_run();
void task7_run();
void task8_run();
void taskMatrix_run();



#ifdef __cplusplus
}
#endif




#endif /* PI_OS_INCLUDE_CIRCLE_TASK_H_ */
