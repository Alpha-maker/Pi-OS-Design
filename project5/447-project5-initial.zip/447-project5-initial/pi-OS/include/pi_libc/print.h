/*
 * print.h
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */

#ifndef PROJECT3_PI_OS_INCLUDE_PI_LIBC_PRINT_H_
#define PROJECT3_PI_OS_INCLUDE_PI_LIBC_PRINT_H_
#include "../../../pi-OS/include/pi_libc/stdarg.h"


#ifdef __cplusplus
extern "C" {
#endif

	void call_printf(const char *pMessage, va_list Args);
	void _sysCallPrint(const char *pMessage);

#ifdef __cplusplus
}
#endif


#endif /* PROJECT3_PI_OS_INCLUDE_PI_LIBC_PRINT_H_ */
