/*
 * print.cpp
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */


#include <pi_libc/print.h>
#include "../../pi-OS/include/pi_libc/string.h"
#include "../../pi-OS/include/pi_libc/print.h"

void call_printf(const char *pMessage, va_list Args){

	CString Message;
	Message.FormatV (pMessage, Args);

	_sysCallPrint((const char *)Message);


}


void _sysCallPrint(const char *pMessage){
	asm("swi 1001");
}

