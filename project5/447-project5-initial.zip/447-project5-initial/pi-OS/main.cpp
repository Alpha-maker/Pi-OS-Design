//
// main.c
//
// pi-OS C++ bare metal environment for Raspberry Pi


#include "../pi-OS/include/circle/kernel.h"
#include "../pi-OS/include/circle/startup.h"

#include "../pi-OS/include/circle/sched.h"
#include "../pi-OS/include/circle/task.h"
#include "../pi-OS/include/circle/softwareinterrupt.h"
static CKernel Kernel;

void kernelPrint(const char * pMessage){

	Kernel.write_log(pMessage);
}


void addKernelTimer(unsigned nDelay,
		   TKernelTimerHandler *pHandler,
		   void *pParam){
	kernelPrint("addKernelTimer is called");
	Kernel.addKernelTimer(nDelay, pHandler,  pParam);
}


void testTimerHandler (unsigned hTimer, void *pParam, void *pContext)
{
	kernelPrint("From testTimerHandler");
	//pThis->write_log("this is from kernel timer handler");
}



void kernelPrintV(const char * pMessage,...){
	va_list var;
	va_start (var, pMessage);
	Kernel.write_logV(pMessage, var);
	va_end (var);
}

/*KERNEL task: TASK ID=0; TASK NUM = 0;
 * 	//The kernel routine: all the kernel codes starts here
 * 	Kernel task doesn't participate scheduling: it's not runnable
 * 	main will call kernelTaskRun after initialize all the tasks, including the kernel task itself(kernel task lies in first place)
 * 	kernelTaskRun serves as the most core function in the OS. Its task ID is 0, and its running span is 0(never ends)
 * 	-------It determines how scheduling system works(By scheduling algorithm)
 * 	-------It determines many other things ... ...
 */
void kernelTaskRun()
{
	Tscheduler * scheduler = getScheduler();
	kernelPrint("KERNEL:: Some one calls the kernel, or the queue just starts over");
	addKernelTimer(3*100, testTimerHandler, 0);
	while (1)
	{
		if (NEEDTOSCHED == scheduler->SchedulerState ){
			startScheduler();
		}
	}
}


#define TASKKERNELID 0
#define TASKSCHEDID 1
#define TASKINTERUPTID 2
#define TASKTIMER0ID 3
#define TASKTIMER1ID 4

#define FILENAME	"circaa.txt"

int main (void)
{
	if (!Kernel.Initialize ())
	{
		halt ();
		return EXIT_HALT;
	}
	kernelPrint("Welcome to ENEE447, Operating System Design Lab");
	Kernel.vfsInitialize();

	/*
	 * ID	| NUM | Task		|runnable 	|  Description
	 * ------------------------------------------------------------------------------
	 * 0	| 0   |kernelTask	|No			|
	 * 1  	| 1   |taskSched	|No			|
	 * 100  | 2   |task1		|Yes		|
	 * 101  | 3   |task2		|Yes		|
	 * 102  | 4   |task3		|Yes		|
	 * 103  | 5   |task4		|Yes		|
	 * 104  | 6   |task5		|Yes		|
	 *
	 *
	 */

	InitializeScheduler();
	sysCall * pSystemCall = getSysCallPointer();
	pSystemCall->print = & kernelPrint;
	pSystemCall->printV = & kernelPrintV;
	pSystemCall->addKernelTimer = & addKernelTimer;

	task_struct * pSchedulerTask = Kernel.createTaskStruct("scheduler", 10);
	Kernel.initTask(pSchedulerTask,&TaskEntry2, 0);
	setSchedulerTask(pSchedulerTask);

	task_struct * pTask4 = Kernel.createTaskStruct("task4", 30);
	task_struct * pTask5 = Kernel.createTaskStruct("task5", 30);
	task_struct * pTask6 = Kernel.createTaskStruct("task6", 30);
	Kernel.initTask(pTask4,&TaskEntry2, &task4_run);
	Kernel.initTask(pTask5,&TaskEntry2, &task5_run);
	Kernel.initTask(pTask6,&TaskEntry2, &task6_run);
	Kernel.schedNewTask(pTask4);
	Kernel.schedNewTask(pTask5);
	Kernel.schedNewTask(pTask6);


	int i =0;
	Tscheduler *scheduler = getScheduler();
	Kernel.write_log("Now print the task queue");
	for(i=0;i<TASKQUEUELEN;i++){
		if( 0 != scheduler->runQueue[i])
		{
			Kernel.write_log("Task_PID=%d, queue_NUM = %d, task=%d, priority=%d"  \
					, scheduler->runQueue[i]->pid, i,scheduler->runQueue[i], scheduler->runQueue[i]->prio);
		}
	}
	scheduler->SchedulerState = NEEDTOSCHED;

	Kernel.write_log("flag 2222");
	setKernelPointer(&Kernel);


	kernelTaskRun();

	//TShutdownMode ShutdownMode = ShutdownHalt;
	TShutdownMode ShutdownMode = Kernel.Run ();

	switch (ShutdownMode)
	{
	case ShutdownReboot:
		reboot ();
		return EXIT_REBOOT;

	case ShutdownHalt:
	default:
		Kernel.write_log("Going to halt");
		halt ();
		Kernel.write_log("Never goes here");
		return EXIT_HALT;
	}
}
