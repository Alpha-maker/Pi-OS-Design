/*
 * main.h
 *
 *  Created on: Feb 9, 2017
 *      Author: wangfakai
 */

#ifndef PI_OS_MAIN_H_
#define PI_OS_MAIN_H_

void MainTaskEntry (Task * pTask);
void kernelRunFunc( Task * pTask );

#endif /* PI_OS_MAIN_H_ */
