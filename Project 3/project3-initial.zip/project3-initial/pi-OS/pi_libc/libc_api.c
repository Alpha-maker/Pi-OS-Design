/*
 * pi-lib.c
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */


#include <circle/stdarg.h>
#include <pi_libc/libc_api.h>
#include "../../pi-OS/include/pi_libc/print.h"
#include "../../pi-OS/include/circle/task.h"
#include "../../pi-OS/include/pi_libc/sleepswitch.h"

static TTaskRegisters TRegs;

////*********   pi-OS-specific system call 1000 ~1100  *********//////

//system call number: 1000;
int pi_lib_test(int a, int b, int c){
	return 0;
	int res=0;
	asm("swi 1000");
	__asm ("mov  %[output], r0"
	:  [output] "=r" (res)
	);
	return res;
}

//system call number: 1001;
int printf(const char * pMessage,...){
	return 0;

	va_list var;
	va_start (var, pMessage);
	call_printf(pMessage, var);
	va_end (var);
}

//system call number: 1002;
int sleep(int nSeconds){
	return 0;
	//TODO

}

//system call number: 1003;
void * getKernelRegPtr(){
	return 0;
	//TODO
}

//system call number: 1004;
void * getCurrentTaskPtr(){
	return 0;
//TODO
}

////////******   Linux system call  0 ~ 337 *******//////

//system call number: 0;
int restart(int ERRNUM){
	asm("swi 0");
}

//system call number: 1;
int exit(int ERRNUM){
	return 0;
	//TODO
}

//system call number: 2;
int fork(int ERRNUM){
	asm("swi 2");
}

//system call number: 3;
int read(int ERRNUM){
	asm("swi 3");
}

//system call number: 4;
int write(int ERRNUM){
	asm("swi 4");
}

//system call number: 5;
int open(int ERRNUM){
	asm("swi 5");
}

//system call number: 6;
int close(int ERRNUM){
	asm("swi 6");
}

