/*
 * pi-lib.c
 *
 *  Created on: Mar 4, 2017
 *      Author: wangfakai
 */


#include <circle/stdarg.h>
#include <pi_libc/print.h>

void pi_lib_test_pre(int a, int b, int c,int d){
	asm("swi 10");
}



void sleep_pre(int seconds){
	asm("swi 10");
}


void printf_pre(const char * pMessage,...){

asm("swi 3");

}


