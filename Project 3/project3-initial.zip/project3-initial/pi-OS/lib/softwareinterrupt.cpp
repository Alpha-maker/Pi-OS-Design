
#include <assert.h>
#include <circle/stdarg.h>
#include "../../pi-OS/include/circle/softwareinterrupt.h"
#include "../../pi-OS/include/circle/synchronize.h"


//INCLUDE kernel header files, so second level handler can call kernel functions
#include "../../pi-OS/include/circle/sched.h"

static CKernel * pKernel;

void setKernelPointer(CKernel * pointerKernel){
	pKernel= pointerKernel;
}

int SWIHandler (unsigned r0, unsigned r1, unsigned r2, unsigned r3)
{
	PeripheralExit ();	// exit from interrupted peripheral
	if( 1001 != r3){  // don't need to print printf REGs,
		pKernel->write_log("SWIHandler::second level SVC handler, r0=%d,r1=%d,r2=%d,r3=%d", r0, r1, r2, r3);
	}

	switch(r3){
	case 1:
		//TODO
		break;
	case 1000: //printf(char *)
		return r0 + r1 * r2;
		break;
	case 1001:
		//TODO
		break;
	case 1002:
		//TODO
		break;
	case 1003:
		//TODO
		break;

	case 1004:
		//TODO
		break;

	default:
		pKernel->write_log("--       SWIHandler:: Receive an undefined system call !");
		break;

	}
	PeripheralEntry ();	// continuing with interrupted peripheral
	return 0;
}

